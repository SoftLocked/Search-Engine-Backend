from preprocessor import BinIndex

if __name__ == "__main__":
    BinIndex(10000).index()