from indexer import Index

if __name__ == "__main__":
    i = Index(10000)
    i.crawl_json()